Email Spam Detection Website:
This project is an email application with an integrated spam detection features. It allows users to send,receive and categorize emails based on their content.
