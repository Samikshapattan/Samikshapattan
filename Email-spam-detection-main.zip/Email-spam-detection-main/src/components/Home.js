import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth'; // Import the useAuth hook

function Home() {
  const { user } = useAuth(); // Destructure user from useAuth

  if (!user) {
    return <p>You must be logged in to view this page.</p>; // If user is not logged in, show a message
  }

  return (
    <div>
      <h1>Welcome, {user.email}</h1> {/* Display user's email */}
      <nav>
        <Link to="/home/inbox">Inbox</Link> | 
        <Link to="/home/sent">Sent</Link> | 
        <Link to="/home/spam">Spam</Link> | 
        <Link to="/home/create-mail">Create Mail</Link>
      </nav>
      <hr />
      <Outlet /> {/* Render nested routes */}
    </div>
  );
}

export default Home;
