// import { useState, useEffect } from "react";
// import { db, auth } from "../firebase";
// import { collection, query, where, getDocs } from "firebase/firestore";

// const Spam = () => {
//   const [spamEmails, setSpamEmails] = useState([]);
//   const [error, setError] = useState("");

//   useEffect(() => {
//     const fetchSpamEmails = async () => {
//       try {
//         const user = auth.currentUser;
//         if (!user) {
//           setError("No user logged in");
//           return;
//         }
//         const q = query(
//           collection(db, "emails"),
//           where("recipient", "==", user.email),
//           where("isSpam", "==", true)
//         );
        
//         const querySnapshot = await getDocs(q);
//         const emails = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

//         setSpamEmails(emails);
//       } catch (err) {
//         setError("Error fetching spam emails: " + err.message);
//       }
//     };

//     fetchSpamEmails();
//   }, []);

//   return (
//     <div>
//       <h2>Spam Emails</h2>
//       {error && <p>{error}</p>}
//       <ul>
//         {spamEmails.map((email) => (
//           <li key={email.id}>
//             <strong>From:</strong> {email.from}
//             <br />
//             <strong>Subject:</strong> {email.subject}
//             <br />
//             <strong>Message:</strong> {email.body}
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default Spam;

import { useState, useEffect } from "react";
import { db, auth } from "../firebase";
import { collection, query, where, getDocs } from "firebase/firestore";

const Spam = () => {
  const [spamEmails, setSpamEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchSpamEmails = async () => {
      try {
        const user = auth.currentUser;

        if (!user) {
          setError("No user is currently logged in. Please log in to view your spam emails.");
          setLoading(false);
          return;
        }

        // Query Firestore to fetch spam emails for the current user
        const q = query(
          collection(db, "emails"), // Ensure "emails" is your collection name
          where("recipient", "==", user.email),
          where("isSpam", "==", true)
        );
       

        const querySnapshot = await getDocs(q);

        if (querySnapshot.empty) {
          setSpamEmails([]);
          setLoading(false);
          return;
        }

        // Map the documents to an array of emails
        const emails = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        setSpamEmails(emails);
      } catch (err) {
        setError("Error fetching spam emails: " + err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchSpamEmails();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Spam Emails</h2>

      {error && <p style={{ color: "red" }}>{error}</p>}

      {loading ? (
        <p>Loading spam emails...</p>
      ) : spamEmails.length === 0 ? (
        <p>No spam emails found in your mailbox.</p>
      ) : (
        <ul style={{ listStyleType: "none", padding: 0 }}>
          {spamEmails.map((email) => (
            <li
              key={email.id}
              style={{
                border: "1px solid #ccc",
                marginBottom: "10px",
                padding: "10px",
                borderRadius: "5px",
                backgroundColor: "#f9f9f9",
              }}
            >
              <p>
                <strong>From:</strong> {email.from || "Unknown Sender"}
              </p>
              <p>
                <strong>Subject:</strong> {email.subject || "No Subject"}
              </p>
              <p>
                <strong>Message:</strong> {email.body || "No Content"}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Spam;

